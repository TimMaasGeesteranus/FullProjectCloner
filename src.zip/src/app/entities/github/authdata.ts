interface Authdata {
  token: string;
  username: string;
}

