import {InviteService} from './invite.service';

describe('InviteService', () => {
  it('empty test', () => {
  });
});
