export enum Errorcode {
  FIREBASE_POPUP_CLOSED = 'auth/popup-closed-by-user',
  FIREBASE_REQUEST_EXESS = 'auth/too-many-requests',
  FIREBASE_NO_USER = 'auth/null-user',
}
