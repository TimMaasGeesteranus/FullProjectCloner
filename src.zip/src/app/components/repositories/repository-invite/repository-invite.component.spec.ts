import {RepositoryInviteComponent} from './repository-invite.component';

describe('RepositoryInviteComponent', () => {
  it('empty test', () => {
  });
});
